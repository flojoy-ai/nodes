# nodes

## Testing your nodes

### running tests
Run `pytest` from the repo root

### creating tests
- Name your tests `<node_name>_test_.py`
- Create your unit tests in the node directory. i.e `/TRANSFORMERS/ARITHMETIC/ADD/ADD_test_.py`
