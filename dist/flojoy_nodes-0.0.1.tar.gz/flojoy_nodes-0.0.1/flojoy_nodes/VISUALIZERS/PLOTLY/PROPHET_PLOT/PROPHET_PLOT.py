from flojoy import flojoy, run_in_venv, DataFrame, Plotly, DataContainer


@flojoy(deps={"prophet": "1.1.4", "holidays": "0.26", "pystan": "2.19.1.1"})
@run_in_venv(
    pip_dependencies=[
        "prophet==1.1.4",
    ]
)
def PROPHET_PLOT(default: DataFrame, data: DataContainer, periods: int = 365) -> Plotly:
    """The PROPHET_PLOT node plots forecasted trend of the time series data passed in

    This is the output plotly graph from the `plot_plotly` function
    from `prophet.plot`

    It expects as input the trained Prophet model from the PROPHET_PREDICT node. If
    `run_forecast` was True in that node, the forecasted dataframe will be available
    here as the `m` dc_input attribute. Otherwise, this will make the predictions on
    the raw dataframe (which will be the `m` attribute in that case). You can tell
    out if that forecasted dataframe is available via the `extra` field "run_forecast"
    of the dc_input (`dc_inputs[0].extra["run_forecast"]`)

    Parameters
    ----------
    periods : int
        The number of periods out to predict. Only used if the node passed into this
        node (ie PROPHET_PREDICT) did NOT return the forecast. If the forecast was
        included in the DataContainer, this param will be ignored.

        Default 365

    Returns
    -------
    DataContainer of type "plotly" with the figure containing the plotted components
    """

    import os
    import sys
    import prophet

    import pandas as pd
    import numpy as np

    from prophet.plot import plot_plotly
    from prophet.serialize import model_from_json

    def _make_dummy_dataframe_for_prophet():
        """Generate random time series data to test if prophet works"""
        start_date = pd.Timestamp("2023-01-01")
        end_date = pd.Timestamp("2023-07-20")
        num_days = (end_date - start_date).days + 1
        timestamps = pd.date_range(start=start_date, end=end_date, freq="D")
        data = np.random.randn(num_days)  # Random data points
        df = pd.DataFrame({"ds": timestamps, "ys": data})
        df.rename(
            columns={df.columns[0]: "ds", df.columns[1]: "y"}, inplace=True
        )  # PROPHET model expects first column to be `ds` and second to be `y`
        return df

    def _apply_macos_prophet_hotfix():
        """This is a hotfix for MacOS. See https://github.com/facebook/prophet/issues/2250#issuecomment-1559516328 for more detail"""

        if not sys.platform == "darwin":
            return

        # Test if prophet works (i.e. if the hotfix had already been applied)
        try:
            _dummy_df = _make_dummy_dataframe_for_prophet()
            prophet.Prophet().fit(_dummy_df)
        except RuntimeError as e:
            print(f"Could not run prophet, applying hotfix...")
        else:
            return

        prophet_dir = prophet.__path__[0]  # type: ignore
        # Get stan dir
        stan_dir = os.path.join(prophet_dir, "stan_model")
        # Find cmdstan-xxxxx dir
        cmdstan_basename = [x for x in os.listdir(stan_dir) if x.startswith("cmdstan")]
        assert len(cmdstan_basename) == 1, "Could not find cmdstan dir"
        cmdstan_basename = cmdstan_basename[0]
        # Run (from stan_dir) : install_name_tool -add_rpath @executable_path/<CMDSTAN_BASENAME>/stan/lib/stan_math/lib/tbb prophet_model.bin
        cmd = f"install_name_tool -add_rpath @executable_path/{cmdstan_basename}/stan/lib/stan_math/lib/tbb prophet_model.bin"
        cwd = os.getcwd()
        os.chdir(stan_dir)
        return_code = os.system(cmd)
        os.chdir(cwd)
        if return_code != 0:
            raise RuntimeError("Could not apply hotfix")

    _apply_macos_prophet_hotfix()

    extra = data.extra
    if not extra or "prophet" not in extra:
        raise ValueError(
            "Prophet model must be available in DataContainer 'extra' key to plot"
        )

    node_name = __name__.split(".")[-1]

    model = model_from_json(extra["prophet"])
    if extra.get("run_forecast") is not None:
        forecast = default.m
    else:
        future = model.make_future_dataframe(periods=periods)
        forecast = model.predict(future)
    fig = plot_plotly(model, forecast)
    fig.update_layout(
        dict(title=node_name, autosize=True, template={}, height=None, width=None),
        overwrite=True,
    )

    return Plotly(fig=fig)
