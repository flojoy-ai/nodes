__all__ = [
    "BSPLINE",
    "CUBIC",
    "DECIMATE",
    "DETREND",
    "GAUSS_SPLINE",
    "HILBERT",
    "KAISER_BETA",
    "PERIODOGRAM",
    "QUADRATIC",
    "SAVGOL_FILTER",
    "STFT",
    "WELCH",
]
